/**
 * API helper functions for communicating with the FastAPI backend
 *
 * Backend endpoints:
 * - GET / → health check
 * - POST /generate → starts video generation
 * - GET /status/:jobId → checks job status (custom endpoint, not provided in requirements)
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

export interface GenerateVideoRequest {
  prompt: string
}

export interface GenerateVideoResponse {
  message: string
  job_id: string
}

export interface JobStatusResponse {
  status: "pending" | "processing" | "completed" | "failed"
  video_url?: string
  error?: string
}

/**
 * Start video generation
 */
export async function generateVideo(prompt: string): Promise<GenerateVideoResponse> {
  const response = await fetch(`${API_BASE_URL}/generate`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ prompt }),
  })

  if (!response.ok) {
    throw new Error(`Failed to generate video: ${response.statusText}`)
  }

  return response.json()
}

/**
 * Check job status
 * Note: This endpoint needs to be implemented on the backend
 */
export async function getJobStatus(jobId: string): Promise<JobStatusResponse> {
  const response = await fetch(`${API_BASE_URL}/status/${jobId}`)

  if (!response.ok) {
    throw new Error(`Failed to get job status: ${response.statusText}`)
  }

  return response.json()
}

/**
 * Health check
 */
export async function healthCheck(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/`)
    return response.ok
  } catch {
    return false
  }
}
